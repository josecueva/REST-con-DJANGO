from django.forms import widgets
from rest_framework import serializers
from escuela.models import Materia, LANGUAGE_CHOICES, STYLE_CHOICES

class MateriaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Materia 
        fields = ('id', 'title', 'code', 'linenos', 'language', 'style')
